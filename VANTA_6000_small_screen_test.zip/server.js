
const express = require("express");
const http = require("http");
const WebSocket = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });
const rooms = new Map();

app.use(express.static("public"));
app.get("/health", (_, res) => res.json({ok:true, app:"VANTA 6000"}));

function room(id){
  if(!rooms.has(id)) rooms.set(id, new Set());
  return rooms.get(id);
}
function broadcast(r, sender, msg){
  for(const ws of r){
    if(ws !== sender && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg));
  }
}

wss.on("connection", ws => {
  let current = null;
  ws.on("message", raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if(m.type === "join"){
      current = String(m.room || "VANTA");
      room(current).add(ws);
      ws.send(JSON.stringify({type:"joined", room:current, count:room(current).size}));
      broadcast(room(current), ws, {type:"system", text:`${m.name || "A user"} joined`, count:room(current).size});
      broadcast(room(current), ws, {type:"peers", count:room(current).size});
      return;
    }
    if(!current) return;
    if(["offer","answer","candidate","ptt","chat"].includes(m.type)){
      broadcast(room(current), ws, {...m, name:m.name || "User"});
    }
  });
  ws.on("close", () => {
    if(current && rooms.has(current)){
      const r=rooms.get(current); r.delete(ws);
      broadcast(r, ws, {type:"peers", count:r.size});
      if(!r.size) rooms.delete(current);
    }
  });
});

const port = process.env.PORT || 3000;
server.listen(port, "0.0.0.0", () => console.log(`VANTA 6000 listening on ${port}`));
