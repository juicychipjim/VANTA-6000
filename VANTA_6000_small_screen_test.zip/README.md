# VANTA 6000 — small-screen real voice test build

This is a phone-friendly web test build with a real WebRTC microphone path, channel room, PTT UI and chat.

To make a shareable live link, deploy this folder to a Node.js host (for example Render) and open the HTTPS URL on two phones. Both phones join the same channel and allow microphone access.

Important: this is a test build, not a finished Play Store APK. It uses a public STUN server only; some mobile networks require a TURN server for reliable peer-to-peer voice. Offline/no-internet voice is not included in this web build.
